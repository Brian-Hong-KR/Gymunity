# Change Log

## [1.0.0] 2023-06-24
### Changes

- STABLE Version
- Regenerate Codebase
  - [React App Generator](https://appseed.us/generator/react/) - free tool 
