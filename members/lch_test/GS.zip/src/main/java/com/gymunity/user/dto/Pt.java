package com.gymunity.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Pt {
	private int userId;
	private String planName;
	private String planDesc;

}//end class
