package com.gymunity.common.exception;

public class ChallengeException extends RuntimeException {
    public ChallengeException(String message) {
        super(message);
    }
}
