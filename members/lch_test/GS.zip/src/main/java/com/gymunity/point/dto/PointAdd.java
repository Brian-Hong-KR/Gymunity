package com.gymunity.point.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PointAdd {
	private int pointsAdded;
	private String addedReason;
	private int userId;

}// end class
