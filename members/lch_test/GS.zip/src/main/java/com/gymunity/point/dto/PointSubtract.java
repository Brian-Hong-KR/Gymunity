package com.gymunity.point.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PointSubtract {
	private int pointsSubtracted;
	private String subtractedReason;
	private int userId;

}// end class
