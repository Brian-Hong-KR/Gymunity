package com.gymunity.challenge.response;

public class ChallengeJoinResponse {

}// end ChallengeJoinResponse
