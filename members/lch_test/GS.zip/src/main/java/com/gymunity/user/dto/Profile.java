package com.gymunity.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Profile {
	private String password;
	private String userEmail;
	private int userId;

}// end class
