package com.gymunity.point.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PointAggr {
	private int totalPoints;
	private int currentPoints;
	private int userId;

}// end class
