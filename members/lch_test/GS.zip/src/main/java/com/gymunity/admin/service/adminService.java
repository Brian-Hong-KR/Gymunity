package com.gymunity.admin.service;

public interface adminService {
	
	public void verifyCheckProcess(int viId, String result);

}// end interface
