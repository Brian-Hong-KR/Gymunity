package com.gymunity.common.exception;

public class ChallengeDuplicateEntryException extends RuntimeException {
	public ChallengeDuplicateEntryException(String message) {
        super(message);
    }
}
