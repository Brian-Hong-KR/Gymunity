package com.gymunity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymunitySpringBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymunitySpringBackendApplication.class, args);
	}

}
