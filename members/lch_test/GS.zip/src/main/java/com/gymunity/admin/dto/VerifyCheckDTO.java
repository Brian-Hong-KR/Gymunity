package com.gymunity.admin.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VerifyCheckDTO {
	private int viId;
	private String result;
}// end VerifyCheckDTO()
