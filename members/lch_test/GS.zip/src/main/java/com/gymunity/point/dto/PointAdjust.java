package com.gymunity.point.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PointAdjust {
	private int pointsAdjusted;
	private String reason;
	private int userId;

}// end class
