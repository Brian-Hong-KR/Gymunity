package com.gymunity.challenge.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Member {
	private int memberId;
	private double achieveRate;
	private int memUserId;
	private int memChId;
//	private int gradeId;
	private String registrant;
	

}// end class
