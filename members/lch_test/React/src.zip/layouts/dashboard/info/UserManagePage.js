import DashboardLayout from 'examples/LayoutContainers/DashboardLayout';
import React from 'react';

const UserManagePage = () => {
  return (
    <div>
      <h1>User 관리 페이지 - 유저 관리(like 삭제)</h1>
      </div>

  );
};

export default UserManagePage;