import React from 'react';

const ModifyPlanPage = () => {
  return (
    <div>
      <h1>Pt 플랜 다시 세우기</h1>
    </div>
  );
};

export default ModifyPlanPage;