const reportsBarChartData = {
  chart: {
    labels: ['Mon', 'Tue', 'Wen', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: { label: 'Point', data: [700, 200, 300, 220, 500, 100, 800] },
  },
};

export default reportsBarChartData;
