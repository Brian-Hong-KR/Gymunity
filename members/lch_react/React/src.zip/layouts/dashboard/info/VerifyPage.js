import React from 'react';

const VerifyPage = () => {
  return (

    <div>
      <h1>사진 인증 관리 페이지 - O/X으로 인증 확인/실패 </h1>
    </div>

  );
};

export default VerifyPage;